Text Summarizer:

Often times, I recieve long emails, or really long texts from teachers, parents, etc, that I may not have the time to read. Or, I may encounter long articles that I have to read for the knowledge on how to do something, hw, etc, and I may not want to read those long articles/pages. For this, I made a natural-language-processing(NLP) text-summarization app using the hugging face API and a python flask app, using git to deploy my project, making it an end to end NLP project. In this project, I further advanced about how to use API's, specifically the hugging face API which is catered to my particular field of data science, the basics of NLP and how to use PyTorch to make my own NLP model, as well as solidified my knowledge on deploying projects and making them end-to-end. 

This README too long for you? Use the text summmarizer :)
